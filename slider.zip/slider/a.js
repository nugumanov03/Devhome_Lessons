console.log("Starting")

wrapper = document.querySelector(".wrapper")

sliders = wrapper.querySelectorAll(".slider")
sliders_2 = sliders[0].cloneNode( true );
wrapper.appendChild(sliders_2)

sliders = wrapper.querySelectorAll(".slider")
btn_left = document.querySelector(".btn_left")
btn_right = document.querySelector(".btn_right")

bullets = document.querySelectorAll(".bullets")

bullet_one = document.querySelector(".bullet-one")
bullet_two = document.querySelector(".bullet-two")
bullet_three = document.querySelector(".bullet-three")

traslateX_value = 0
for(var i=0; i<sliders.length; i++){
    sliders[i].style.transform =  `translateX(${traslateX_value}%)`
}

btn_left.addEventListener("click", ()=>{
    console.log("Нажата левая")
    
    traslateX_value = traslateX_value + 100
    for(var i=0; i<sliders.length; i++){
        sliders[i].style.transform = `translateX(${traslateX_value}%)`
    }
})
btn_right.addEventListener("click", ()=>{
    console.log("Нажата right")
    console.log(traslateX_value)
    if(traslateX_value == 0){
        bullet_one.classList.toggle("bullet-active")
        bullet_two.classList.toggle("bullet-active")
    }
    if(traslateX_value == -100){
        bullet_two.classList.toggle("bullet-active")
        bullet_three.classList.toggle("bullet-active")
    }

    if(traslateX_value <= -100){
        traslateX_value += 100
        sliders[0].remove()
        sliders = wrapper.querySelectorAll(".slider")
        sliders_new = sliders[0].cloneNode( true );
        wrapper.appendChild(sliders_new)
        sliders = wrapper.querySelectorAll(".slider")
        // return
    }
    // bullet_three.classList   .toggle("bullet-active")
    
    for(var i=0; i< sliders.length; i++){
        sliders[i].style.transform = `translateX(${traslateX_value}%)`
        const newspaperSpinning = [
            { transform: `translateX(${traslateX_value}%)` },
            { transform: `translateX(${traslateX_value-100}%)` },
          ];
          
          const newspaperTiming = {
            duration: 1000,
            iterations: 1,
          };
          
        sliders[i].animate(newspaperSpinning, newspaperTiming);
        sliders[i].style.transform = `translateX(${traslateX_value-100}%)`  
    }
    traslateX_value = traslateX_value - 100
    
})